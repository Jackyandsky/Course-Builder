// Shared constants for the application
export const SHARED_USER_ID = '4ef526fd-43a0-44fd-82e4-2ab404ef673c';