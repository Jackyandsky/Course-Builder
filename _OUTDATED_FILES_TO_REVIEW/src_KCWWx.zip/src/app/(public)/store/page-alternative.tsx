'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import ProductListing from '@/components/products/ProductListing';

interface TransformedProduct {
  id: string;
  title: string;
  author: string;
  description: string;
  price: number;
  imageUrl: string | undefined;
  category: string;
  type: string;
}

export default function StorePage() {
  const [products, setProducts] = useState<TransformedProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const supabase = createClientComponentClient();
  const searchParams = useSearchParams();
  const categoryParam = searchParams.get('category');

  useEffect(() => {
    loadProducts();
  }, [categoryParam]);

  // Reset products when loading
  useEffect(() => {
    setLoading(true);
  }, [categoryParam]);

  const loadProducts = async () => {
    try {
      // Alternative approach: Use RPC function or raw SQL query
      // First, let's try to get all content with categories, ignoring RLS
      const storeCategories = ['Decoders', 'Complete Study Packages', 'Standardizers', 'LEX'];
      
      // Get category IDs first
      const { data: categoriesData } = await supabase
        .from('categories')
        .select('id, name')
        .in('name', categoryParam ? [categoryParam] : storeCategories);
      
      if (!categoriesData || categoriesData.length === 0) {
        setProducts([]);
        return;
      }

      const categoryIds = categoriesData.map(cat => cat.id);
      const categoryMap = Object.fromEntries(categoriesData.map(cat => [cat.id, cat.name]));

      // Try to fetch content directly with a more permissive query
      // This approach fetches content and manually joins categories
      const { data: contentData, error: contentError } = await supabase
        .from('content')
        .select('*')
        .in('category_id', categoryIds)
        .order('name');

      if (contentError) {
        console.error('Error loading content:', contentError);
        // Fallback: try the API route
        const params = new URLSearchParams();
        if (categoryParam) {
          params.append('category', categoryParam);
        } else {
          storeCategories.forEach(cat => params.append('categories', cat));
        }
        
        const response = await fetch(`/api/public/store-products?${params.toString()}`);
        if (response.ok) {
          const data = await response.json();
          setProducts(data);
          return;
        }
      }

      // Transform content data
      const transformedProducts = contentData?.map(product => ({
        id: product.id,
        title: product.name,
        author: product.metadata?.author || 'IGPS',
        description: product.content?.substring(0, 200) + '...' || '',
        price: product.metadata?.price || 29.99,
        imageUrl: product.metadata?.image_url || undefined,
        category: categoryMap[product.category_id] || 'Uncategorized',
        type: 'store'
      })) || [];

      setProducts(transformedProducts);
    } catch (error) {
      console.error('Error loading products:', error);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  const categories = ['Decoders', 'Complete Study Packages', 'Standardizers', 'LEX'];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <ProductListing
      products={products}
      type="store"
      title="Store"
      subtitle="Premium educational materials and study resources"
      categories={categories}
      initialCategory={categoryParam || undefined}
    />
  );
}