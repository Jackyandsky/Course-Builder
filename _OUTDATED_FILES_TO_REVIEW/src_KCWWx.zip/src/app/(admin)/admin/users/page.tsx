'use client';

import { useState, useEffect } from 'react';
import { Users, UserPlus, Upload, Filter, Search, GraduationCap } from 'lucide-react';
import { getUsersByRole, getUserGroups } from '@/lib/supabase/user-management';
import { getCourses } from '@/lib/supabase/courses';
import type { UserProfile, UserRole, UserGroup } from '@/types/user-management';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Table } from '@/components/ui/Table';
import { SearchBox } from '@/components/ui/SearchBox';
import { Badge } from '@/components/ui/Badge';
import { Select } from '@/components/ui/Select';
import { Modal } from '@/components/ui/Modal';
import EnrollmentManager from '@/components/enrollments/EnrollmentManager';
import AddUserModal from '@/components/users/AddUserModal';
import BulkImportModal from '@/components/users/BulkImportModal';
import { useAuth } from '@/contexts/AuthContext';

export default function UsersPage() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole | 'all'>('all');
  const [showEnrollments, setShowEnrollments] = useState(false);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showBulkImportModal, setShowBulkImportModal] = useState(false);

  useEffect(() => {
    loadData();
  }, [selectedRole]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load users based on selected role
      if (selectedRole === 'all') {
        const roles: UserRole[] = ['student', 'teacher', 'parent', 'admin'];
        const allUsers: UserProfile[] = [];
        
        for (const role of roles) {
          const { data, error } = await getUsersByRole(role);
          if (error) {
            console.error(`Error loading ${role} users:`, error);
          }
          if (data) {
            console.log(`Found ${data.length} ${role} users:`, data);
            allUsers.push(...data);
          }
        }
        
        console.log('Total users found:', allUsers.length);
        setUsers(allUsers);
      } else {
        const { data, error } = await getUsersByRole(selectedRole);
        if (error) {
          console.error(`Error loading ${selectedRole} users:`, error);
        }
        console.log(`Found ${data?.length || 0} ${selectedRole} users:`, data);
        setUsers(data || []);
      }

      // Load groups
      const { data: groupsData, error: groupsError } = await getUserGroups();
      if (groupsError) {
        console.error('Error loading groups:', groupsError);
      }
      setGroups(groupsData || []);
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = users.filter(user => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      user.full_name?.toLowerCase().includes(search) ||
      user.id.toLowerCase().includes(search)
    );
  });

  const roleOptions = [
    { value: 'all', label: 'All Roles' },
    { value: 'student', label: 'Students' },
    { value: 'teacher', label: 'Teachers' },
    { value: 'parent', label: 'Parents' },
    { value: 'admin', label: 'Administrators' },
  ];

  const columns = [
    { 
      key: 'name', 
      label: 'Name',
      render: (user: UserProfile) => (
        <div>
          <p className="font-medium">{user.full_name || 'Unnamed User'}</p>
          <p className="text-sm text-gray-600">{user.email || `ID: ${user.id.slice(0, 8)}...`}</p>
        </div>
      )
    },
    { 
      key: 'role', 
      label: 'Role',
      render: (user: UserProfile) => {
        const variants = {
          admin: 'danger' as const,
          teacher: 'primary' as const,
          student: 'secondary' as const,
          parent: 'success' as const,
          guest: 'ghost' as const,
        };
        return (
          <Badge variant={variants[user.role] || 'secondary'}>
            {user.role}
          </Badge>
        );
      }
    },
    { 
      key: 'grade_level', 
      label: 'Grade',
      render: (user: UserProfile) => user.grade_level ? `Grade ${user.grade_level}` : '-'
    },
    { 
      key: 'created_at', 
      label: 'Joined',
      render: (user: UserProfile) => new Date(user.created_at).toLocaleDateString()
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">User Management</h1>
          <p className="text-gray-600 mt-1">Manage students, teachers, parents, and administrators</p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="secondary"
            leftIcon={<GraduationCap className="h-4 w-4" />}
            onClick={() => setShowEnrollments(!showEnrollments)}
          >
            {showEnrollments ? 'Hide' : 'Show'} Enrollments
          </Button>
          <Button 
            variant="secondary"
            leftIcon={<Upload className="h-4 w-4" />}
            onClick={() => setShowBulkImportModal(true)}
          >
            Bulk Import
          </Button>
          <Button 
            leftIcon={<UserPlus className="h-4 w-4" />}
            onClick={() => setShowAddUserModal(true)}
          >
            Add User
          </Button>
        </div>
      </div>

      {/* Enrollment Manager */}
      {showEnrollments && (
        <EnrollmentManager />
      )}

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <Card.Content className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Students</p>
                <p className="text-2xl font-bold text-gray-900">
                  {users.filter(u => u.role === 'student').length}
                </p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </Card.Content>
        </Card>
        
        <Card>
          <Card.Content className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Teachers</p>
                <p className="text-2xl font-bold text-gray-900">
                  {users.filter(u => u.role === 'teacher').length}
                </p>
              </div>
              <Users className="h-8 w-8 text-green-500" />
            </div>
          </Card.Content>
        </Card>
        
        <Card>
          <Card.Content className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Parents</p>
                <p className="text-2xl font-bold text-gray-900">
                  {users.filter(u => u.role === 'parent').length}
                </p>
              </div>
              <Users className="h-8 w-8 text-purple-500" />
            </div>
          </Card.Content>
        </Card>
        
        <Card>
          <Card.Content className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Groups</p>
                <p className="text-2xl font-bold text-gray-900">{groups.length}</p>
              </div>
              <Users className="h-8 w-8 text-orange-500" />
            </div>
          </Card.Content>
        </Card>
      </div>

      {/* Users Table */}
      <Card>
        <Card.Content className="p-6">
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <SearchBox
                placeholder="Search by name or ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onSearch={() => {}}
              />
            </div>
            <Select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value as UserRole | 'all')}
              options={roleOptions}
              className="w-48"
            />
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div>
            </div>
          ) : filteredUsers.length > 0 ? (
            <Table
              columns={columns}
              data={filteredUsers}
            />
          ) : (
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No users found</p>
              <p className="text-sm text-gray-500 mt-2">
                {searchTerm ? 'Try adjusting your search criteria' : 'Create your first user to get started'}
              </p>
            </div>
          )}
        </Card.Content>
      </Card>

      {/* Add User Modal */}
      <AddUserModal
        isOpen={showAddUserModal}
        onClose={() => setShowAddUserModal(false)}
        onUserCreated={() => {
          setShowAddUserModal(false);
          loadData();
        }}
      />

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={showBulkImportModal}
        onClose={() => setShowBulkImportModal(false)}
        onImportComplete={() => {
          setShowBulkImportModal(false);
          loadData();
        }}
      />
    </div>
  );
}