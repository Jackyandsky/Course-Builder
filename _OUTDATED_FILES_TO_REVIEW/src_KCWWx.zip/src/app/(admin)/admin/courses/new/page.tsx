'use client';

import { CourseForm } from '@/components/courses/CourseForm';

export default function NewCoursePage() {
  return <CourseForm />;
}
