'use client';

import { BookForm } from '@/components/books/BookForm';

export default function NewBookPage() {
  return <BookForm />;
}