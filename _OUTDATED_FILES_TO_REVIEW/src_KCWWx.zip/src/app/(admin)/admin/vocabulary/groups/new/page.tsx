import { VocabularyGroupForm } from '@/components/vocabulary';

export default function NewVocabularyGroupPage() {
  return <VocabularyGroupForm />;
}
