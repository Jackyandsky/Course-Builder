import { VocabularyForm } from '@/components/vocabulary';

export default function NewVocabularyPage() {
  return <VocabularyForm />;
}
