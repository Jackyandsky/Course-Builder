import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';

// Create a Supabase client with the service role key to bypass RLS
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
);

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const category = searchParams.get('category');
    const categories = searchParams.getAll('categories');

    // Base query for store products with category join
    let query = supabaseAdmin
      .from('content')
      .select(`
        *,
        category:categories!category_id(
          id,
          name,
          type
        )
      `);

    // If a specific category is requested
    if (category) {
      const { data: categoryData } = await supabaseAdmin
        .from('categories')
        .select('id')
        .eq('name', category)
        .single();
        
      if (categoryData) {
        query = query.eq('category_id', categoryData.id);
      }
    } else if (categories.length > 0) {
      // Load products from specified categories
      const { data: categoriesData } = await supabaseAdmin
        .from('categories')
        .select('id')
        .in('name', categories);
        
      if (categoriesData && categoriesData.length > 0) {
        const categoryIds = categoriesData.map(cat => cat.id);
        query = query.in('category_id', categoryIds);
      }
    }

    const { data, error } = await query.order('name');

    if (error) {
      console.error('Error fetching store products:', error);
      return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 });
    }

    // Transform the data to match the expected format
    const transformedProducts = data?.map(product => ({
      id: product.id,
      title: product.name,
      author: product.metadata?.author || 'IGPS',
      description: product.content?.substring(0, 200) + '...' || '',
      price: product.metadata?.price || 29.99,
      imageUrl: product.metadata?.image_url || undefined,
      category: product.category?.name || 'Uncategorized',
      type: 'store'
    })) || [];

    return NextResponse.json(transformedProducts);
  } catch (error) {
    console.error('Error in store products API:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}